#
# The Widget Construction Kit
# $Id: //modules/tkinter3000/WCK/__init__.py#4 $
#
# wck redirector
#

VERSION = "1.0"

from wckTkinter import *
from Utils import *
